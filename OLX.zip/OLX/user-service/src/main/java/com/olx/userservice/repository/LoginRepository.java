package com.olx.userservice.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;
import com.olx.userservice.pojo.UserPojo;


@Repository
public interface LoginRepository extends MongoRepository<UserPojo, String>{
	
	UserPojo findByPhoneNoAndPassword(String phoneNo,String password);

	UserPojo findByEmailIdAndPassword(String emailId,String password);
	
	
}
