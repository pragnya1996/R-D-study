package com.olx.userservice.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.olx.userservice.pojo.UserPojo;
import com.olx.userservice.repository.LoginRepository;


@Service
public class LoginService {
	
	@Autowired
	public LoginRepository loginrepository;

	public UserPojo findByPhoneNoAndPassword(String phoneNo, String password) {
		return loginrepository.findByPhoneNoAndPassword(phoneNo, password) ;
	}

	public UserPojo findByEmailIdAndPassword(String emailId, String password) {
		return loginrepository.findByEmailIdAndPassword(emailId, password);
	}
	

}
