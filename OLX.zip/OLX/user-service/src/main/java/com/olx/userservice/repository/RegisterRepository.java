package com.olx.userservice.repository;



import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Component;

import com.olx.userservice.pojo.UserPojo;
@Component
public interface RegisterRepository extends MongoRepository<UserPojo,String> {
	
	UserPojo findByPhoneNo(String phoneNo);

	UserPojo findByEmailId(String emailId);

	
	
}

