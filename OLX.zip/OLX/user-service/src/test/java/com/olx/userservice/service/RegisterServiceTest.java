package com.olx.userservice.service;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import com.olx.userservice.pojo.UserPojo;
import com.olx.userservice.repository.RegisterRepository;

@RunWith(MockitoJUnitRunner.class)
public class RegisterServiceTest {
@Mock
RegisterRepository regRepo;

@InjectMocks
RegisterService registerService;


@Test
public void findByEmail1()
	{
		UserPojo register2=new UserPojo();
		register2.setEmailId("prabhu@gmail.com");
		Mockito.when(regRepo.findByEmailId("prabhu@gmail.com")).thenReturn(register2);
		assertEquals(registerService.findByEmailId("prabhu@gmail.com").getEmailId(), "prabhu@gmail.com");
		
	}
@Test
public void findByEmail2()
	{
	UserPojo register2=new UserPojo();
	register2.setEmailId("prabhu@gmail.com");
	Mockito.when(regRepo.findByEmailId("prabhu@gmail.com")).thenReturn(register2);
	assertEquals(registerService.findByEmailId(null).getEmailId(), "prabhu@gmail.com");
	}
@Test
public void findByPhone1()
{
	UserPojo register2=new UserPojo();
	register2.setPhoneNo("9876543210");
	Mockito.when(regRepo.findByPhoneNo("9876543210")).thenReturn(register2);
	assertEquals(registerService.findByPhoneNo("9876543210").getPhoneNo(), "9876543210");
	
}

@Test
public void findByPhone2()
{
	UserPojo register2=new UserPojo();
	register2.setPhoneNo("9876543210");
	Mockito.when(regRepo.findByPhoneNo("9876543210")).thenReturn(register2);
	assertEquals(registerService.findByPhoneNo(null).getPhoneNo(), "9876543210");
	
}
@Test
public void addRegister2() {
	 UserPojo register=new UserPojo("pragnya","abc","123","abc@gmail.com","1287","123","free",true);
	 Mockito.when(registerService.addregister(register)).thenReturn(register);
	 UserPojo reg1=registerService.addregister(null);
		//System.out.println(reg1);
		Assert.assertNotNull(reg1);
		}
@Test
public void addRegister1() {
	 UserPojo register=new UserPojo("pragnya","abc","123456","abc@gmail.com","9876543210","123","free",true);
	 Mockito.when(registerService.addregister(register)).thenReturn(register);
	 UserPojo reg1=registerService.addregister(register);
		//System.out.println(reg1);
		Assert.assertNotNull(reg1);
}
@Test
	public void getAllProductTest_1()
	{
		List<UserPojo> regList=new ArrayList<UserPojo>();
		UserPojo register=new UserPojo("pragnya","abc","123456","abc@gmail.com","9876543210","123","free",true);
		regList.add(register);
		register=new UserPojo("pragnya","abc","123456","abc@gmail.com","9876543210","123","free",true);
		regList.add(register);
		Mockito.when(registerService.findAll()).thenReturn(regList);
		List<UserPojo> registers=registerService.findAll();
		Assert.assertEquals(regList.size(),registers.size());

}
@Test
public void updateReg_1()
	{
		UserPojo register1=new UserPojo("pragnya","abc","123456","abc@gmail.com","9876543210","123","free",true);
		Mockito.when(registerService.updateregister(register1)).thenReturn(register1);
		UserPojo reg1=registerService.updateregister(register1);
		Assert.assertNotNull(reg1);
		
	}
	@Test
	public void updateReg_2()
	{
		UserPojo register1=new UserPojo("pragnya","abc","123456","abc@gmail.com","9876543210","123","free",true);
		Mockito.when(registerService.updateregister(register1)).thenReturn(register1);
		UserPojo reg1=registerService.updateregister(null);
		Assert.assertNotNull(reg1);
		
	}

}
