package com.olx.webui.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

import com.olx.webui.pojo.UserPojo;

@Controller
public class RegisterController {
	 
	@Autowired
	private DiscoveryClient discoveryClient;
	
	@PostMapping(value="/signup")
	public ModelAndView signup(@ModelAttribute("user") UserPojo user){
		
		List<ServiceInstance> instances = discoveryClient.getInstances("user-service"); 
		ServiceInstance serviceInstance=instances.get(0);
		String baseUrl=serviceInstance.getUri().toString();
		RestTemplate restTemplate = new RestTemplate();
		String url = null;
		ModelAndView mav = new ModelAndView();
	    
	    url = baseUrl + "/email/" + user.getEmailId();
	    UserPojo res = restTemplate.getForObject(url, UserPojo.class);	     
	    if(res!=null){
	    	mav.addObject("error", "Email Id already present");
	    	mav.setViewName("register");
	    	return mav;
	    }
	    
	    url = baseUrl + "/phone/" + user.getPhoneNo();
		res = restTemplate.getForObject(url, UserPojo.class);	     
	    if(res!=null){
	    	mav.addObject("error", "Phone Number already present");
	    	mav.setViewName("register");
	    	return mav;
	    }
		
		url=baseUrl+"/create";	 
	    UserPojo result = restTemplate.postForObject( url, user, UserPojo.class);
		System.out.println(result.toString());
		mav.addObject("msg", "Account created successfully");
		mav.setViewName("LoginForm");
		return mav;
	}
}
